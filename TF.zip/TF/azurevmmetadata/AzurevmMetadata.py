import json
import os
from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from dotenv import load_dotenv
load_dotenv()
subscription_id = os.getenv("SUBSCRIPTIONID")
resource_group_name = os.getenv("RESOURCEGROUPNAME")
vm_name = os.getenv("VMNAME")

def get_az_vm_metadata(subscription_id, resource_group_name, vm_name):
    # Use DefaultAzureCredential to authenticate
    credentials = DefaultAzureCredential()
    
    # Initialize ComputeManagementClient with the correct parameter names
    client = ComputeManagementClient(credentials, subscription_id)
    
    try:
        # Use the correct parameter names when calling virtual_machines.get
        vm = client.virtual_machines.get(resource_group_name, vm_name)
        
        # Extract VM metadata
        vm_metadata = {
            "VMName": vm.name,
            "VMID": vm.id,
            "VMSize": vm.hardware_profile.vm_size,
            "ProvisioningState": vm.provisioning_state,
            
            # Add more properties as needed
        }
        
        print(json.dumps(vm_metadata, indent=2))
    except Exception as e:
        # Print the actual error message
        print(f"Error: {e}")

if __name__ == "__main__":
    get_az_vm_metadata(subscription_id, resource_group_name, vm_name)
