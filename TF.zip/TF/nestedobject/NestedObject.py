def getNestedvalue(inp, ky):
      
      print("The original dictionary is : " + str(inp))
      res = [val[ky] for val in inp.values() if ky in val.keys()]
      return res

if __name__ == "__main__":
   inputobj = eval(input("Enter the nested object: "))
   #inputobj = {'sds' : {"nn" : 100, "b" : 3, "c" : 12},
        #     'hghg' : {"f" : 105, "nn" : 33, "c" : 20}, 
        #     'hgh' :{"c" : 3, "b" : 6, "nn" : 2}}
   ky = input("Enter the key: ")
  #ky = "nn"
   result = getNestedvalue(inputobj, ky)
   print(f"The value of ${ky} is : " + str(result))
